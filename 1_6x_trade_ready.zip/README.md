# 1.6X TRADE

Demo trading simulator using a 1:1.6 risk/reward model.

- Demo balance: $1000
- Risk slider
- Automatic reward = risk × 1.6
- Long / Short
- 1x–50x leverage selector
- Demo trade history
- Win-rate statistics

This is a prototype. It does not connect to a crypto exchange and does not use real money.
